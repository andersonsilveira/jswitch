java -Dfile.encoding=UTF-8 -jar ./lib/jswitch-dist.jar
