java -Dfile.encoding=UTF-8 -jar ./dist/jswitch-dist.jar
